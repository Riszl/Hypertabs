const http = require('http');
const fs = require('fs');
const path = require('path');
const server = http.createServer();
const fetch = require('./fetch');
const Corrosion = require('../');
const proxy = new Corrosion({
  codec: 'xor',
	prefix: '/service/',
	forceHttps: true
});

proxy.bundleScripts();

server.on('request', (request, response) => {
    if (request.url.startsWith(proxy.prefix)) {
      if (!dexor(request.url.split('/')[request.url.split('/').length - 1]).startsWith('http')) {

      }
      return proxy.request(request, response);
    }
    if (request.url.startsWith('/get-title/')) return getTitle(request, response);
    if (request.url==='/main.html') return response.end(fs.readFileSync(__dirname + '/main.html', 'utf-8'));
    if (request.url==='/inspect.js') return response.end(fs.readFileSync(__dirname + '/inspect.js', 'utf-8'));
    if (request.url==='/css.css') return response.end(fs.readFileSync(__dirname + '/css.css', 'utf-8'));
    if (request.url==='/favicon.ico') return response.end(fs.readFileSync(__dirname + '/favicon.ico'));
    response.end(fs.readFileSync(__dirname + '/index.html', 'utf-8'));
}).on('upgrade', (clientRequest, clientSocket, clientHead) => proxy.upgrade(clientRequest, clientSocket, clientHead)).listen(process.env.PORT || 7070);

var xor = (str)=>(encodeURIComponent(str.split('').map((char,ind)=>ind%2?String.fromCharCode(char.charCodeAt()^2):char).join('')));
var dexor = (str)=>(decodeURIComponent(str).split('').map((char, ind) => ind % 2 ? String.fromCharCode(char.charCodeAt() ^ 2) : char).join(''))

const getTitle = (req, res) => {
  //node fetch because im hella lazy
  console.log(req.url.split('/'))
  try {
    //var url = dexor(req.url.split('/')[2])
    new URL('discord.com')
  } catch(err) {
    var url = dexor(dexor(encodeURIComponent(req.url))).replace('/get-title/https:/', 'https://')
    var split = url.split('/service/')
    split[1] = encodeURIComponent(split[1])
    url = dexor(dexor(dexor(split[1])))
  }
  console.log(url)
  fetch(url, {'buffer': false, 'promise': false, 'method': 'GET'}, (content) => {
    var win = new (require('jsdom').JSDOM)(content); document = win.window.document
    res.end(document.title)
  })
}

const upperFirstLetter = (string) => {
  string[0] = string[0].toUpperCase()
  return string
}